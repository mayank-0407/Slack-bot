import slack
import os
# from pathlib import path

TOKEN='xoxb-4544836295238-5008060995252-kLz4uKXcEJIr6azKHDvgYkZR'

client= slack.WebClient(token=TOKEN)

client.chat_postMessage(channel='#text', text='Hello!')